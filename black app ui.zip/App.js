import React from "react";
import MainRoute from './route/MainRoute'
function App(){
  return(
 <MainRoute />
  )}
export default App;
