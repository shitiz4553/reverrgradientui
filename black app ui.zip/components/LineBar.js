import React from "react";
import { 
    View,
    Text,
    StyleSheet
} from "react-native";

function LineBar(){
    return(
    <View style={styles.container}>
    </View>
    )}
export default LineBar;

const styles = StyleSheet.create({
    container: {
       width:'100%',
       height:1,
       backgroundColor:'#7c7c7c',
    }
});